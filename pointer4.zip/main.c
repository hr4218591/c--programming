/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int x[5]={1,2,3,4,5};
    int * ptr;
    ptr=&x[0];
    printf("*ptr=%d\n",ptr);
      printf("*(ptr+1)=%d\n",*(ptr+1));
      printf("*(ptr-1)=%d",*(ptr-1));
     return 0;
}

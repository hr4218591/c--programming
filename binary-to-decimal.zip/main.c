/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
void main()
{
    int n,sum=0,count=0,rem;
    while(n>0)
    {
        rem=n%10;
        sum=sum+pow(2,count)*rem;
        n/=10;
        count+=1;
    }
    printf("%d",sum);

}

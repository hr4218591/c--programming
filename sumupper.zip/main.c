/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h> 
void main() 
{ 
 int mat[3][3]; 
 int i,j,row,col,sum=0; 
 printf("Enter the number of rows and columns for matrix\n"); 
 scanf("%d%d",&row,&col); 
 printf("Enter the elements of the matrix\n"); 
 for(i=0;i<row;i++) 
 { 
 for(j=0;j<col;j++) 
 { 
 scanf("%d",&mat[i][j]); 
 } 
 } 
 printf("The matrix\n"); 
 for(i=0;i<row;i++) 
 { 
 for(j=0;j<col;j++) 
 { 
 printf("%d\t",mat[i][j]); 
 } 
 printf("\n"); 
 } 
 for(i=0;i<row;i++) 
 { 
 for(j=0;j<col;j++) 
 { 
 if(i<j) 
 { 
 sum=sum+mat[i][j]; 
 } 
 } 
 } 
 printf("The sum of upper triangular elements = %d\n",sum); 
}
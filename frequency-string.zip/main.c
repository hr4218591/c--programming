/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{
  int i=0;
  char s1[10]="beautiful";
  int count=0;
  int n=strlen(s1);
  for(i=0;i<n;i++)
  {
 
  	if(s1[i]=='u' )
  	{
  		count=count+1;
  	
	  }
	  
  }
	  printf("The count of u are %d\n",count);

}
 
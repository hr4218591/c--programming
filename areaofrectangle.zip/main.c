/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int l,b,area;
    printf("Enter the length of rectangle");
    scanf("%d",&l);
     printf("Enter the width of rectangle");
     scanf("%d",&b);
     area=l*b;
     printf("Area of rectangle is %d\n",area);
}


/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int row,col,i,j,a[10][10];
   printf("Enter no of rows");
   scanf("%d",&row);
   printf("Enter no of Columns");
   scanf("%d",&col);
   printf("Enter Element of Matrix");
   for(i = 0; i < row; i++)
   {
      for(j = 0; j < col; j++)
      {
         scanf("%d",&a[i][j]);
      }
   }
    for (i = 0; i < row; ++i) {
        for (j = 0; j < col; ++j) {
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }

    printf("\nUpper triangular matrix is: \n");
    for (i = 0; i < row; i++) {

        for (j = 0; j < col; j++) {
            if (i < j)
                printf("%d ", a[i][j]);
            else
                printf("  ");
        }
        printf("\n");
    }
    return 0;
}


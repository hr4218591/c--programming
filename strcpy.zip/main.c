/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
int main()
{
    int length;
    char src[20]="Destination";
    char dest[20]="";
    printf("\n source string is =%s",src);
    printf("\n destination string is =%s",dest);
    strcpy(dest,src);
    printf("\n target string after strcpy()=%s",dest);
    return 0;
    
}

#include<stdio.h>

void main()
{
	int a, b, c;
	
	printf("Enter three numbers\n");
	scanf("%d %d %d", &a, &b, &c);
	
   if((a < b) && (a < c)) 
   {
	printf("a is smallest\n");
   }
	else if(b < c) 
	{
	    printf("b is smallest\n");
	}
	else
	{
	printf("c is smallest\n");
}
}
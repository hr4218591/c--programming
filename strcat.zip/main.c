/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char s1[10]="Ram";
    char s2[10]="Ramayan";
    strcat(s1,s2);
    printf("string concatenates=%s\n",s1);
        printf("string concatenates=%s\n",s2);
    return 0;
}

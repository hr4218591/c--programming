/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int main(){
   int row,col,i,j,a[10][10],count = 0;
   printf("Enter no of rows");
   scanf("%d",&row);
   printf("Enter no of Columns");
   scanf("%d",&col);
   printf("Enter Element of Matrix");
   for(i = 0; i < row; i++)
   {
      for(j = 0; j < col; j++)
      {
         scanf("%d",&a[i][j]);
      }
   }
   
   /*checking sparse of matrix*/
   for(i = 0; i < row; i++)
   {
      for(j = 0; j < col; j++)
      {
         if(a[i][j] == 0)
            count++;
      }
   }
   if(count > ((row * col)/2))
      printf("Matrix is a sparse matrix ");
   else
      printf("Matrix is not sparse matrix");
}